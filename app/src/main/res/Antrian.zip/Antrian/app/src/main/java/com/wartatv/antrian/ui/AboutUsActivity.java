package com.wartatv.antrian.ui;

public class AboutUsActivity {
}
